import { NextResponse } from "next/server";
import { createClient } from "@/supabase/server";
import { v4 as uuidv4 } from "uuid";
import { Buffer } from "buffer";
import axios from "axios";
import path from "path";
import { spawn } from "child_process";
import fs from "fs/promises";

export async function POST(req: Request) {
  const formData = await req.formData();
  const businessName = formData.get("businessName") as string;
  const category = formData.get("category") as string;
  const font = formData.get("font") as string;
  const logo = formData.get("logo") as File | null;

  const { supabase } = createClient(req);
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  // Upload logo to Supabase
  let logoUrl = "";
  if (logo) {
    try {
      const buffer = Buffer.from(await logo.arrayBuffer());
      const logoPath = `logos/${uuidv4()}-${logo.name}`;
      const { error } = await supabase.storage
        .from("user-logos")
        .upload(logoPath, buffer, { contentType: logo.type });

      if (!error) {
        const { data } = supabase.storage.from("user-logos").getPublicUrl(logoPath);
        logoUrl = data.publicUrl;
      }
    } catch (err) {
      console.error("Logo upload error:", err);
    }
  }

  // Generate voiceover using ElevenLabs
  const voiceoverText = `Come grab a slice at ${businessName}. Hot, fresh, and made with love.`;
  let voiceoverUrl = "";
  try {
    const elevenRes = await axios.post(
      "https://api.elevenlabs.io/v1/text-to-speech/EXAVITQu4vr4xnSDxMaL",
      {
        text: voiceoverText,
        model_id: "eleven_monolingual_v1",
        voice_settings: { stability: 0.4, similarity_boost: 0.75 },
      },
      {
        headers: {
          "xi-api-key": process.env.ELEVENLABS_API_KEY!,
          "Content-Type": "application/json",
        },
        responseType: "arraybuffer",
      }
    );

    const voiceBuffer = Buffer.from(elevenRes.data);
    const voicePath = `voiceovers/${uuidv4()}.mp3`;

    const { error } = await supabase.storage
      .from("user-voiceovers")
      .upload(voicePath, voiceBuffer, {
        contentType: "audio/mpeg",
      });

    if (!error) {
      const { data } = supabase.storage.from("user-voiceovers").getPublicUrl(voicePath);
      voiceoverUrl = data.publicUrl;
    }
  } catch (err) {
    console.error("TTS error:", err);
  }

  // Static video clip
  const videoUrl = "https://udwjyhoabfttxsztssrj.supabase.co/storage/v1/object/public/video-assets/restaurants/pizza-restaurant/pizza-fixed.mp4";

  // Final props
  const renderProps = {
    businessName,
    font,
    logoUrl,
    voiceoverUrl,
    videoUrl,
  };

  const outFileName = `out-${uuidv4()}.mp4`;
  const outPath = path.resolve(`./public/videos/${outFileName}`);
  const propsPath = path.resolve(`./tmp/${uuidv4()}-props.json`);

  await fs.mkdir(path.dirname(propsPath), { recursive: true });
  await fs.writeFile(propsPath, JSON.stringify(renderProps));

  const command = `npx remotion render remotion/index.tsx studio ${outPath} --props=${propsPath}`;
  console.log("🚀 Rendering video with command:", command);
  console.log("🔧 Render props:", renderProps);

  return new Promise((resolve) => {
    const child = spawn(command, { shell: true });

    child.stdout.on("data", (data) => console.log(`[render] ${data}`));
    child.stderr.on("data", (data) => console.error(`[render error] ${data}`));

    child.on("close", async (code) => {
      if (code !== 0) {
        return resolve(
          NextResponse.json({ error: `Remotion failed with code ${code}` }, { status: 500 })
        );
      }

      const buffer = await fs.readFile(outPath);
      const videoPath = `final-videos/${outFileName}`;

      const { error: uploadError } = await supabase.storage
        .from("final-videos")
        .upload(videoPath, buffer, {
          contentType: "video/mp4",
        });

      if (uploadError) {
        console.error("Upload error:", uploadError);
      }

      const { data } = supabase.storage.from("final-videos").getPublicUrl(videoPath);
      const publicUrl = data.publicUrl;

      // ✅ INSERT VIDEO METADATA TO DB
      const { error: dbError } = await supabase.from("video_prompts").insert({
        user_id: user.id,
        business_name: businessName,
        category,
        font,
        logo_url: logoUrl,
        voiceover_url: voiceoverUrl,
        video_url: publicUrl,
      });

      if (dbError) {
        console.error("DB insert error:", dbError.message);
      }

      resolve(
        NextResponse.json({
          videoUrl: publicUrl,
          voiceoverUrl,
          logoUrl,
          props: renderProps,
        })
      );
    });
  });
}
